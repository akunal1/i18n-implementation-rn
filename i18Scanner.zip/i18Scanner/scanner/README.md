# i18n-implementation-rn
I18n example 

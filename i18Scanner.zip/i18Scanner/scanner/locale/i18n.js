// import { Localization } from 'expo';

import i18next from 'i18next';
import {initReactI18next} from 'react-i18next';
// import {reactI18nextModule} from 'react-i18next';
// import {reactI18nextModule} from 'react-i18next';

import ICU from 'i18next-icu';

// translation files

import en from './en_gb/en_gb.json';

const resources = {
  en: {translation: en},
};

// Config
i18next
  .use(
    new ICU({
      localeData: en, // you also can pass in array of localeData
    }),
  )
  .use(initReactI18next)
  // .use(reactI18nextModule)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    // returnObjects: true,
    interpolation: {
      escapeValue: true,
      // escape(str) {
      //   return str.replace('88', 'LLLLLOOOOLLLLL');
      // },
      // prefix: '{',
      // suffix: '}',
      // prefixEscaped: '<ex>',
      // suffixEscaped: '</ex>',
      // formatSeparator: ',',
      // format(value, format, lng) {
      //   if (format === 'plural') return value.toUpperCase() + '000HI';
      //   return value.replace(new RegExp('<ph><ex>.*</ex>'), '');
      // },
    },
    keySeparator: '&#46;',
    debug: true,
    load: 'all',
    ns: ['translation'], // <-- specify the NS's exists
    defaultNS: 'translation', // <-- what is the default namespace
    react: {
      wait: true,
      // transSupportBasicHtmlNodes: true,
      // // transKeepBasicHtmlNodesFor: ['ph', 'strong', 'i', 'p'],
      // transEmptyNodeValue: 'HHHHHHHH',
    },
  });

export default i18next;

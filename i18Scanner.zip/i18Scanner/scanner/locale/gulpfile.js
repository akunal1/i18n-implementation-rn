var gulp = require('gulp');
var scanner = require('i18next-scanner');

gulp.task('i18next', function () {
  return gulp
    .src('../src/*.js')
    .pipe(
      scanner({
        lngs: ['en'], // supported languages
        resource: {
          // the source path is relative to current working directory
          loadPath: './en_gb/en_gb.json',

          // // the destination path is relative to your `gulp.dest()` path
          savePath: './{{lng}}/{{ns}}.json',
        },
      }),
    )
    .pipe(gulp.dest('assets'));
});

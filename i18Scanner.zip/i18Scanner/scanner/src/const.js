import i18next from '../locale/i18n';
import i18n from '../locale/i18n';

// const teamMemberData = {firstName: 'Aviansh'};
export const blueCar = i18next.t('new-status');
export const redCar = i18next.t('admin-permission-msg', {
  teamMemberData: 'hi',
});
